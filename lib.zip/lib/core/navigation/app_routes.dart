class AppRoutes {
  const AppRoutes._();
  static const splash = '/splash';
  static const login = '/login';
  static const settings = '/settings';
  static const company = '/company';
  //Rutas de sistema
  static const home = '/home';
  static const sedes = '/sedes';
  static const roles = '/roles';//ver
  static const usuarios = '/usuarios';
  static const clientes = '/clientes';
  static const lugaresOperativos = '/lugares-operativos';
  static const puestos = '/puestos';
  static const frutas = '/frutas';
  static const variedades = '/variedades';
  static const calidades = '/calidades';
  static const tiposJaba = '/tipos-jaba';
  static const camiones = '/camiones';
}
