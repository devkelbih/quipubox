import 'package:quipubox/features/sedes/domain/enums/tipo_sede.dart';

import '../../domain/entities/sede.dart';

class SedeRequestModel {
  final int? idEmpresa;
  final String nombre;
  final TipoSede tipoSede;
  final String? direccion;
  final String? ciudad;
  final String? departamento;

  const SedeRequestModel({
    this.idEmpresa,
    required this.nombre,
    required this.tipoSede,
    this.direccion,
    this.ciudad,
    this.departamento,
  });

  factory SedeRequestModel.fromEntity(Sede sede) {
    return SedeRequestModel(
      idEmpresa: sede.idEmpresa,
      nombre: sede.nombre,
      tipoSede: sede.tipoSede,
      direccion: sede.direccion,
      ciudad: sede.ciudad,
      departamento: sede.departamento,
    );
  }

  Map<String, dynamic> toCreateJson() => {
        if (idEmpresa != null) 'id_empresa': idEmpresa,
        if (nombre.trim().isNotEmpty) 'nombre': nombre.trim(),
        'tipo_sede': tipoSede.value,
        if (direccion != null && direccion!.trim().isNotEmpty)
          'direccion': direccion!.trim(),
        if (ciudad != null && ciudad!.trim().isNotEmpty)
          'ciudad': ciudad!.trim(),
        if (departamento != null && departamento!.trim().isNotEmpty)
          'departamento': departamento!.trim(),
      };

  Map<String, dynamic> toUpdateJson() => {
        if (nombre.trim().isNotEmpty) 'nombre': nombre.trim(),
        'tipo_sede': tipoSede.value,
        if (direccion != null && direccion!.trim().isNotEmpty)
          'direccion': direccion!.trim(),
        if (ciudad != null && ciudad!.trim().isNotEmpty)
          'ciudad': ciudad!.trim(),
        if (departamento != null && departamento!.trim().isNotEmpty)
          'departamento': departamento!.trim(),
      };
}